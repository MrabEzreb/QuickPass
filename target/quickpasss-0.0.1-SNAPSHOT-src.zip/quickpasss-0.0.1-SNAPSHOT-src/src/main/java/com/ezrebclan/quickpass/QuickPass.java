package com.ezrebclan.quickpass;

public class QuickPass {

	public static void main(String[] args) {
		
	}

}
